﻿using BlogApp.Data;
using BlogApp.Models.Domain;
using BlogApp.Models.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Reflection.Metadata;
using static System.Reflection.Metadata.BlobBuilder;

namespace BlogApp.Controllers
{
    public class UserController: Controller
    {
        private readonly BlogDbContext blogDbContext;

        public UserController(BlogDbContext blogDbContext)
        {
            this.blogDbContext = blogDbContext;
        }

        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Register(RegisterUserRequest registerUserRequest) 
        {
            var user = new Users
            {
                Name = registerUserRequest.Name,
                Username = registerUserRequest.userName,
                Email = registerUserRequest.Email,
                Password = registerUserRequest.Password
            };


            blogDbContext.Users.Add(user);
            blogDbContext.SaveChanges();

            return RedirectToAction("Login", "User");
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(LoginUserRequest loginUserRequest)
        {

            var user = blogDbContext.Users
                .FirstOrDefault(u => u.Username == loginUserRequest.userName);

            if (user == null || loginUserRequest.Password != user.Password)
            {
                ModelState.AddModelError(string.Empty, "Invalid username or password.");
                return View(loginUserRequest);
            }

            HttpContext.Session.SetString("Username", user.Username);
            return RedirectToAction("Home", "User");
        }


            public IActionResult Home()
            {
                var blogs = blogDbContext.BlogPosts.OrderByDescending(b => b.PublishedDate).ToList();

                var userName = HttpContext.Session.GetString("Username");

                var viewModel = new BlogViewModel
                {
                    Blogs = blogs,
                    SuccessMessage = TempData["Message"] as string
                };

                return View(viewModel);
            }


        public IActionResult AddBlog()
        {
            // Retrieve the username from the session
            string userName = HttpContext.Session.GetString("Username");

            if (string.IsNullOrEmpty(userName))
            {
                // If the username is not found in the session, redirect to login page
                return RedirectToAction("Login", "User");
            }

            ViewData["Username"] = userName;  // Pass the username to the view
            return View();
        }

        [HttpPost]
        
        public IActionResult AddBlog(AddBlogRequest addBlogRequest)
        {
           
                // Get the username from the session
                string userName = HttpContext.Session.GetString("Username");

                var blog = new BlogPost
                {
                    Title = addBlogRequest.Title,
                    Content = addBlogRequest.Content,
                    PublishedDate = DateTime.Now,
                    UserId = userName
                };

                blogDbContext.BlogPosts.Add(blog);
                blogDbContext.SaveChanges();

                TempData["Message"] = "Blog added successfully!";

                return View();
        }

        public IActionResult MyBlogs()
        {
            // Assuming you're storing the username in session after login
            var userName = HttpContext.Session.GetString("Username");

            if (string.IsNullOrEmpty(userName))
            {
                return RedirectToAction("Login", "User");
            }

            var userBlogs = blogDbContext.BlogPosts
                                    .Where(b => b.UserId == userName)
                                    .OrderByDescending(b => b.PublishedDate)
                                    .ToList();

            var viewModel = new BlogViewModel
            {
                Blogs = userBlogs,
                SuccessMessage = TempData["Message"] as string
            };

            return View(viewModel);

        }

        [HttpPost]
        public IActionResult DeleteBlog(Guid id)
        {
            var blog = blogDbContext.BlogPosts.FirstOrDefault(b => b.Id == id);

            if (blog != null)
            {
                blogDbContext.BlogPosts.Remove(blog);
                blogDbContext.SaveChanges();
                TempData["Message"] = "Blog deleted successfully!";
            }

            return RedirectToAction("MyBlogs");
        }

        [HttpPost]
        public IActionResult Logout()
        {
            // Clear the session to log out the user
            HttpContext.Session.Remove("Username");  // Assuming you store the username in session

            // Redirect to the home page or login page
            return RedirectToAction("Index", "Home");
        }

    }
}
