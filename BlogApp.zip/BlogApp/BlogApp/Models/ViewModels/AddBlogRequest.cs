﻿namespace BlogApp.Models.ViewModels
{
    public class AddBlogRequest
    {
        public string Title { get; set; }

        public string Content { get; set; }

        public DateTime PublishedTime { get; set; }

        public string UserId { get; set; }
    }
}
