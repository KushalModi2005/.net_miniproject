﻿namespace BlogApp.Models.ViewModels
{
    public class LoginUserRequest
    {

        public String userName { get; set; }

        public string Password { get; set; }
    }
}
