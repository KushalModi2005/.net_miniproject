﻿namespace BlogApp.Models.ViewModels
{
    public class RegisterUserRequest
    {
        public String Name { get; set; }

        public String userName { get; set; }    

        public string Email { get; set; }

        public string Password { get; set; }
    }
}
