﻿using BlogApp.Models.Domain;
using System.Reflection.Metadata;

namespace BlogApp.Models.ViewModels
{
    public class BlogViewModel
    {
        public List<BlogPost> Blogs { get; set; }
        public string SuccessMessage { get; set; }
    }
}
